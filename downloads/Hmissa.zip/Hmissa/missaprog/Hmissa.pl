#!/usr/bin/perl

#�����������
# Name : Laszlo Kiss
# Date : 09-25-08
# Divine Office

package missa;
#1;
                        
#use warnings;
#use strict "refs";
#use strict "subs";
#use warnings FATAL=>qw(all);

our $padx = 10;
our $pady = 10;
our $widthperc = .99;
our $heightperc = .90;

use POSIX;
use FindBin qw($Bin);
use File::Basename;
use Time::Local;
#use DateTime;
use locale;
use utf8;
use Cwd;

use Tk;
use Tk::Widget;
use Tk::widgets;
use Tk::Checkbutton;
use Tk::Scale;
use Tk::Dialog;
use Tk::Pane;
use Tk::Scrollbar;
use Tk::Radiobutton;
use Tk::Optionmenu;
use Tk::Text;
use Tk::ErrorDialog;
use Tk::Font;
use Tk::Table;
use WIN32;
use Win32::Process;

our $officium = 'missa.pl';
our $version = 'Rubrics 1960';
our $Propers = 0;
our $missanumber = 1;

$iexplore = 'iexplore';
if (-e "C:/Program Files/Mozilla Firefox/firefox.exe") {$iexplore = 'firefox';}

#***common variables arrays and hashes
#filled  getweek()
our @dayname; #0=Advn|Natn|Epin|Quadpn|Quadn|Pascn|Pentn 1=winner title|2=other title

#filled by getrank()
our $winner; #the folder/filename for the winner of precedence
our $commemoratio; #the folder/filename for the commemorated
our $scriptura; #the folder/filename for the scripture reading (if winner is sancti)
our $commune; #the folder/filename for the used commune
our $communetype; #ex|vide
our $rank; #the rank of the winner
our $laudes; #1 or 2
our $vespera; #1 | 3 index for ant, versum, oratio
our $cvespera; #for commemoratio
our $commemorated; #name of the commemorated  for vigils
our $comrank = 0; #rank of the commemorated office

#filled by precedence()
our %winner; #the hash of the winner 
our %commemoratio; #the hash of the commemorated
our %scriptura; #the hash for the scriptura
our %commune; # the hash of the commune
our (%winner2, %commemoratio2, %commune2); #same for 2nd column
our $rule; # $winner{Rank}
our $communerule; # $commune{Rank}
our $duplex; #1=simplex-feria, 2=semiduplex-feria privilegiata, 3=duplex 
             # 4= duplex majus, 5 = duplex II classis 6=duplex I classes 7=above  0=none

#*** collect standard items
require "dialogcommon.pl";
#require "ordocommon.pl";
require "../horas/horascommon.pl";
require "ordo.pl";
require "propers.pl";
require "../horas/Hwebdia.pl";
require "Hmsetup.pl";
require "tfertable.pl";

#get parameters
getini('Hmissa'); #files, colors

our $Hk = ($mbrfolder && -e "$mbrfolder/phoplayer.exe") ? 3 : 1;
our $Tk = 0;
our $Ck = 0;
our $pdf = 0;
our $missa = 1;

our ($lang1, $lang2, $column);
our %translate; #translation of the skeleton label for 2nd language 
our ($voicecolumn, $doline, $keyfreq, $dofreq, $basetime,$voweltime, $vowelmod, $mono);
our $sanctiname = 'Sancti';
our $temporaname = 'Tempora';
our $communename = 'Commune';

our $mw = MainWindow->new();

#internal script, cookies
our %dialog = %{setupstring("$datafolder/Hmissa.dialog")};
our %setup = %{setupstring("$datafolder/Hmissa.setup")};
eval $setup{general};
eval $setup{'parameters'};
eval $setup{'Chant'};	      
$testmode = ($testmode =~ /season/i) ? $testmode : 'regular';
$votive = 'proper';

our $command = '';
our $hora = $command; #Matutinum, Laudes, Prima, Tertia, Sexta, Nona, Vespera, Completorium
our $votive = 'proper';
our $expandnum = 0;
       
if ($geometry) {
  my $g = $geometry;
  $g =~ s/\+/x/;
  my @g = split('x', $g);
  if (($g[0] + $g[2]) > $mw->screenwidth || 
    ($g[1] + $g[3]) > $mw->screenheight) {$geometry = '';}
}

our $fullwidth = floor($mw->screenwidth * $widthperc);
our $fullheight = floor($mw->screenheight * $heightperc);
our $anteflag = 0;
if (!$geometry) {$geometry = $fullwidth . "x$fullheight+0+0";}
$mw->geometry($geometry);
$mw->configure(-title=>'Generate Text');

$mw->configure(-background=>"#ffffdd", -height=>$fullheight, -width=>$fullwidth);
$mw->OnDestroy(\&finalsave);

$firstcall = 0;
our @command = splice(@command, @command);
mainpage();
$firstcall = 0;
MainLoop();


#*** mainpage();
# creates the opening and horas pages
sub mainpage {  
                
if ($firstcall == 1) {return;}
$firstcall = 1;
$mw->configure(-title=>"Generate Text");
$error = '';

our $only = ($lang1 =~ /$lang2/) ? 1 : 0;
our ($width, $blackfont, $redfont, $smallblack, $smallfont, $titlefont,
  $black, $red, $blue);

if ($lang1 !~ /Latin/i && $voicecolumn =~ /Latin/i) {$voicecolumn = 'mute';}
if ($lang2 !~ /Magyar/i && $voicecolumn =~ /Magyar/i) {$voicecolumn = 'mute';}
if ($Hk < 3) {$voicecolumn = 'mute';}

if ($ARGV[0] =~ /cleantab/) {cleantab();}
 
$mwf = $mw->Scrolled('Pane', -scrollbars=>'osoe',
 -width=>$fullwidth, -height=>$fullheight, -background=>"#ffffdd")
 ->pack(-side=>'top', -padx=>$padx, -pady=>$pady);

our $datefrom = gettoday();
our $numofdays = 1;
our $outdir = "$Bin";

$labelfont = "{Arial} 12";
$framecolor = "#ffffdd";

#*** topframe
$topframe = $mwf->Frame(-background=>"#ffffdd")->pack(-side=>'top', -ipady=>50);
$topframe->Button(-text=>"Generate Text",  -font=>$labelfont, -command=>sub{generate();})
  ->pack(-side=>'left', -padx=>$padx);
$topframe->Label(-text=>'From: ', -background=>"#ffffdd", -foreground=>'maroon')
  ->pack(-side=>'left', -padx=>$padx);
$topframe->Entry(-textvariable=>\$datefrom, -width=>10, -background=>"#ffffdd")
  ->pack(-side=>'left', -padx=>$padx);	   
$topframe->Label(-text=>' days: ', -background=>"#ffffdd", -foreground=>'maroon')
  ->pack(-side=>'left', -padx=>$padx);
$topframe->Entry(-textvariable=>\$numofdays, -width=>10, -background=>"#ffffdd")
  ->pack(-side=>'left', -padx=>$padx);	   
$topframe->Label(-text=>' Into: ', -background=>"#ffffdd", -foreground=>'maroon')
  ->pack(-side=>'left', -padx=>$padx);
$topframe->Entry(-textvariable=>\$outdir, -width=>32, -background=>"#ffffdd")
  ->pack(-side=>'left', -padx=>$padx);	   

#*** bottomframe
$bottomframe = $mwf->Frame(-background=>"#ffffdd")->pack(-side=>'top', -ipady=>50);

$bframe1 = $bottomframe->Frame(-background=>"#ffffdd")->pack(-side=>'top', -pady=>10);
  $bframe1->Label(-text=>'Rubrics', -borderwidth=>0, -font=>'Arial 10', 
     -foreground=>'maroon', -background=>"#ffffdd")->pack(-side=>'left', -padx=>10);
  $bframe1->Checkbutton(-variable=>\$rubrics, -command=>sub{mainpage();})->pack(-side=>'left', -padx=>10);
  $bframe1->Label(-text=>'Solemn', -borderwidth=>0, -font=>'Arial 10', 
     -foreground=>'maroon', -background=>"#ffffdd")->pack(-side=>'left', -padx=>10);
  $bframe1->Checkbutton(-variable=>\$solemn, -command=>sub{mainpage();})->pack(-side=>'left', -padx=>10);
  $bframe1->Label(-text=>'Propers only', -borderwidth=>0, -font=>'Arial 10', 
     -foreground=>'maroon', -background=>"#ffffdd")->pack(-side=>'left', -padx=>10);
  $bframe1->Checkbutton(-variable=>\$Propers, -command=>sub{mainpage();})->pack(-side=>'left', -padx=>10);

$bframe2 = $bottomframe->Frame(-background=>"#ffffdd")->pack(-side=>'top', -pady=>10);

my 	@names = ('Version', 'Mode', 'Column2', 'Votive');
for ($i = 0; $i < @names; $i++) {
  $item = $names[$i];  
  $bframe2->Label(-text=>"$names[$i]", -borderwidth=>0, -font=>"{Arial} 10", 
     -foreground=>'maroon', -background=>"#ffffdd")
     ->grid(-column=>$i, -row=>0, -padx=>$padx, -pady=>$pady);
}

@versions = ('Trident 1570', 'Trident 1910', 'Divino Afflatu', 'Reduced 1955', 'Rubrics 1960', '1960 Newcalendar');
$bframe2->Optionmenu(-options=>\@versions,-textvariable=>\$version, #-background=>$framecolor,
   -border=>1, -font=>$labelfont, -command=>sub{mainpage();})
   ->grid(-column=>0, -row=>1, -padx=>$padx, -pady=>$pady);
                      
@optarray3 = ('Regular', 'Seasonal', 'Season', 'Saint');
$bframe2->Optionmenu(-options=>\@optarray3,-textvariable=>\$testmode, #-background=>$framecolor,
  -border=>1, -font=>$labelfont, -command=>sub{mainpage();})
  ->grid(-column=>1, -row=>1, -padx=>$padx, -pady=>$pady);

opendir(DIR, $datafolder); 
@a = readdir(DIR);
close DIR;
@optarray4 = splice(@optarray4, @optarray4);
foreach $item (@a) {
  if ($item !~ /\./ && (-d "$datafolder/$item") && 
    $item =~ /^[A-Z]/ && $item !~ /(tmp|help)/i) {push(@optarray4, $item);}
}		
$bframe2->Optionmenu(-options=>\@optarray4,-textvariable=>\$lang2, #-background=>$framecolor,
   -border=>1, -font=>$labelfont, -command=>sub{mainpage();})
   ->grid(-column=>2, -row=>1, -padx=>$padx, -pady=>$pady);


@optarray5 = ('proper', 'hodie');
if (opendir(DIR, "$datafolder/Latin/Votive")) {
  @a = readdir(DIR); 
  closedir DIR;
  my $item;
  foreach $item (@a) {if ($item =~ /\.txt/i) {$item =~ s/\.txt//i; push(@optarray5, $item);}} 
}

$bframe2->Optionmenu(-options=>\@optarray5,-textvariable=>\$votive, #-background=>$framecolor,
   -border=>1, -font=>$labelfont,
   -command=>sub{mainpage();})
   ->grid(-column=>3, -row=>1, -padx=>$padx, -pady=>$pady);

$bframe3 = $bottomframe->Frame(-background=>"#ffffdd")->pack(-side=>'top', -pady=>$pady);

$bframe3->Button(-text=>'Options', -command=>sub{setuptable('parameters');})
  ->pack(-side=>'left', -padx=>$padx);

my $odir =$outdir;
$odir =~ s/\//\\/g;

$bframe3->Button(-text=>'Browse', -command=>sub{system("start explorer \"$odir\"");})
  ->pack(-side=>'left', -padx=>$padx);
#$bframe3->Button(-text=>'Help',
#  -command=>sub{system("start iexplore $datafolder/../horas/Help/Hhelp.html");}) 
#  ->pack(-side=>'left', -padx=>$padx, -pady=>$pady);  

$bottomframe->Label(-textvariable=>\$error, -background=>"#ffffdd", -foreground=>'red')
    ->pack(-side=>'top', -pady=>$pady);
$bottomframe->Label(-textvariable=>\$message, -background=>"#ffffdd", -foreground=>'maroon')
    ->pack(-side=>'top', -pady=>$pady);

$mwf->pack(-anchor=>'n');
$mwf->idletasks();
$firstcall = 0;
}  

sub errorTk {
  my $str = shift; 
  $mw->messageBox(-title=>'Error', -message=>$str, -type=>'OK');
}


#*** finalsave()
# called before exit
# saves horas.setup file with the current values
sub finalsave {
  setsetup('general', $version, $testmode, $lang2, 'proper', $rubrics, $solemn);
  if ($savesetup) {
    savesetuphash('Hmissa', \%setup);
  }      
}

sub prevnext {
  my $inc = shift;
  my $date1 = shift;
  my ($month, $day, $year) = split('-', $date1);

  my $time = date_to_days($day,$month-1,$year);
  
  my @d = days_to_date($time + $inc);
  $month = $d[4]+1;
  $day = $d[3];
  $year = $d[5]+1900;     
  $date1 = "$month-$day-$year";
}

sub configure {
  my ($widget, $bgcolor, $fontline, $color) = @_;	 

  my ($font, $c) = setfont($fontline);
  if (!$color) {$color = $c;}	 
  $widget->configure(-font=>"Arial 10", -foreground=>"maroon", -background=>"#ffffdd");
}

sub generate {
  my $maxnum = 0;
  our $date1 = $datefrom;
  if ($numofdays > 367) {$numofdays = 367;}
  if ($numofdays < 1) {$numofdays = 1;}

  while ($maxnum < $numofdays) {
    our ($month, $day, $year) = split('-', $date1);
    $outdir =~ s/\/\s*$//;
	  if (!(d- "$outdir")) {mkdir("$outdir");}
	  if (!(d- "$outdir/Files")) {mkdir("$outdir/Files");}
      our $command = 'missa';
      $hora = $command;
      if ($votive =~ /proper/i) {$votive = '';}
	  precedence($date1); #fills our hashes et variables  
	  generatehora();
	  savehtml(); 
      while ($winner =~ /m(\d)\.txt/i) {
        $missanumber = $1 + 1; 
        $winner =~ s/m\d\.txt/m$missanumber\.txt/i;
	    if (-e "$datafolder/Latin/$winner") {precedence($date1); generatehora(); savehtml(); next;}
	    last;
      }

	  
    $maxnum++;
    $date1 = prevnext(1, $date1);
  }
  $message = "Text for $maxnum days are generated<BR>";
  $message .= "For Nook or Kindle see 'Help' 'Hints' section in HOfficium download";  

  $mw->update();
}

sub savehtml {	  
  my $y = sprintf("%02i%02i%02i", $month, $day, $year % 100);
  if ($winner =~ /(m\d)\.txt/i) {$y .= $1;}
  if ($votive && $votive !~ /(proper|hodie)/i) {$y = $votive;}
  my $vletter = ($version =~ /Monastic/i) ? 'M' : ($version =~ /1570/) ? 'O' : ($version =~ /Trident/i) ? 'T' :
       ($version =~ /1955/) ? 'P' : ($version =~ /New/) ? 'N' : ($version =~ /1960/) ? 'R' : '';
  if (open(OUT, ">$outdir/Files/M$y$vleter.html")) {
    print OUT $htmltext;
    close OUT;
    if ($iexplore =~ /firefox/ && $pdf) {
	  $mycwd = getcwd();
	  chdir("$outdir/Files/");
	  unlink("Missa$y.pdf");
	  system("start firefox -print Missa$y.html -printfile Missa$y.pdf");
	  chdir($mycwd);
     }
   } else {print "$outdir/Files/Missa$y.html cannot open\n"; last;}
}    

sub generatehora {  
  $daycolor =   ($commune =~ /(C1[0-9])/) ? 'blue' :
    ($dayname[1] =~ /(Quattuor|Feria|Vigilia)/i) ? $black : 
    ($dayname[1] =~ /duplex/i) ? 'red' : 
	$titlecolor; 
  $commentcolor = ($dayname[2] =~ /Feria/i) ? $black : ($dayname[2] =~ /Sabbato/i) ? $blue : $titlecolor;
  $comment = $dayname[2];

  our $psalmnum1 = 0;
  our $psalmnum2 = 0;                           
  our $htmltext = '';
	  
  # prepare title	   

  #prepare main frames
  $title = "M$month-$day-$year";
  $message = "$month-$day-$year $title";
  $mw->update();
  
  $background = ($whitebground) ? "BGCOLOR=\"white\"" : "BGCOLOR=\"$framecolor\"";

  $headline = setheadline();
  htmlHead($title);
  $htmltext .= "<BODY VLINK=$visitedlink LINK=$link BGCOLOR=\"$framecolor\"> ";
  $htmltext .= 
    "<P ALIGN=CENTER><FONT COLOR=$daycolor>$dayname[1]<BR></FONT>\n" .
    "$comment<BR><BR>\n" .
    "<FONT COLOR=MAROON SIZE=+1><B><I>$title</I></B></FONT>\n" .
    "    </P>\n";
  ordo(Missa); 
  $htmltext .= "</BODY></HTML>";

  if ($only && $celllength < 10000) {
    $htmltext =~ s/<(TABLE|TR|TD).*?>//ig;
    $htmltext =~ s/<\/(TABLE|TR|TD)>//ig;
  }

  if (!$accented) {$htmltext = deaccent1($htmltext);}


}  


sub cleantab {
  if (opendir(DIR, "$datafolder/../horas/Latin/Tabulae")) {
    @a = readdir(DIR);
	closedir(DIR);
	foreach my $fname (@a) {
	  if ($fname =~ /(Tr|Str)(M|1570|1910|DA|1960|Newcal)([0-9]+)/ && ($3 < 2008 || $3 > 2015)) 
	    {if (unlink("$datafolder/../horas/Latin/Tabulae/$1$2$3.txt") == 0) 
		   {print "$datafolder/../horas/Latin/Tabulae/$1$2$3.txt cannot delete\n";}}
    } 
  }
  else {print "$datafolder/../horas/Latin/Tabulae folder do not open\n";}
}

sub setcheckbox {
  my $widget = shift;
  my $str = shift;
  my $var = shift;

  my $label = $widget->Label(-text=>$str)->pack(-side=>'left');
  configure($label, $framecolor, $smallblack);
  my $check = $widget->Checkbutton(-variable=>\$pdf)->pack(-side=>'left');
  configure($check, $framecolor, $blackfont);
  my $label = $widget->Label(-text=>'  ')->pack(-side=>'left');
  configure($label, $framecolor, $smallblack);
  return $check;
}
