#!/usr/bin/perl

#�����������
# Name : Laszlo Kiss
# Date : 09-25-08
# Divine Office Kalendarium

package missa;
#1;

#use warnings;
#use strict "refs";
$a = 4;

sub kalendar {
  $hora = '';
  
  $kmonth = $month; 
  $kyear = $year;
  @origyear = split('-', gettoday()); 

  $smallgray = $smallblack;
  $boldblue = addattribute($bluefont, 'bold', $blue);
  $boldblack = addattribute($blackfont, 'bold', $black);
  $boldred = addattribute($blackfont, 'bold', $red);
  $italicblue = addattribute($linkfont, 'italic', $blue);
  $italicblack = addattribute($blackfont, 'italic', $black);
  $italicred = addattribute($blackfont, 'italic', $red);

  kalendarrut($kmonth, $kyear);

  $mw->bind("<Key-Down>"=>sub{$mwf->yview(scroll, "$scrollamount", 'units')}); 
  $mw->bind("<Key-Up>"=>sub{$mwf->yview(scroll, "-$scrollamount", 'units')}); 
  $mw->bind("<Key-Next>"=>sub{$mwf->yview('scroll', "0.5", 'pages')}); 
  $mw->bind("<Key-Prior>"=>sub{$mwf->yview('scroll', "-0.5", 'pages')}); 
  $mw->bind('<MouseWheel>' => \&mouse_scroll);

}

sub kalendarrut {
  my $kmonth = shift;
  my $kyear = shift; 

@monthnames = ('Januarius', 'Februarius', 'Martius', 'Aprilis', 'Majus', 'Junius',
  'Julius', 'Augustus', 'September', 'October', 'November', 'December');
@monthlength = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
@daynames = ('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fry', 'Sat');

$title = "Kalendarium: $monthnames[$kmonth-1] $kyear";
                                  
if ($mwf) {$mwf->destroy();}
$mw->idletasks();

$mwf = $mw->Scrolled('Pane', -scrollbars=>'osoe',
 -width=>$fullwidth, -height=>$fullheight, -background=>$framecolor)
 ->pack(-side=>'top', -padx=>$padx, -pady=>$pady);

#*** topframe
$topframe = $mwf->Frame(-background=>$framecolor)->pack(-side=>'top', -pady=>$pady);
$top1 = $topframe->Frame(-background=>$framecolor)->pack(-side=>'top');
my $i;
for ($i = $origyear[2] - 5; $i <= $origyear[2]; $i++) {setky($top1, $i);}
$top1->Button(-text=>'hodie', -background=>$framecolor, -borderwidth=>0, -foreground=>$blue,
  -command=>sub{$date1 = gettoday(); mainpage();})
  ->pack(-side=>'left', -padx=>$padx);
for ($i = $origyear[2] + 1; $i < $origyear[2] + 7; $i++) {setky($top1, $i);}


$top2 = $topframe->Frame(-background=>$framecolor)->pack(-side=>'top');
$lb = $top2->Label(-text=>$title, -background=>$framecolor)->pack(-side=>'left', -padx=>$padx);
configure($lb, $framecolor, $titlefont, $titlecolor);

$top3 = $topframe->Frame(-background=>$framecolor)->pack(-side=>'top');
for ($i = 1; $i < 13; $i++) {setkm($top3, $i);}

$middleframe = $mwf->Frame(-background=>$framecolor, -borderwidth=>1, -relief=>'solid')
  ->pack(-side=>'top', -pady=>$pady);

table_start();

$to = $monthlength[$kmonth - 1];   
if ($kmonth == 2 && leapyear($kyear)) {$to++;}  
for ($cday = 1; $cday <= $to; $cday++) {
  $date1 = sprintf("%02i-%02i-%04i", $kmonth, $cday, $kyear);
  $d1 = sprintf("%02i",  $cday);
  $winner = $commemoratio = $scriptura = '';
  %winner = %commemoratio = %scriptura = {};
  $initia = 0;
  $votive = '';

  precedence($date1); #for the daily item      
  @c1 = split(';;', $winner{Rank});
  @c2 = (exists($commemoratio{Rank})) ? split(';;', $commemoratio{Rank}) :
    (exists($scriptura{Rank}) && ($c1[3]!~ /ex C[0-9]+[a-z]*/i ||
    ($version =~ /trident/i && $c1[2] !~ /(ex|vide) C[0-9]/i))) ? 
     split(';;', "Scriptura: $scriptura{Rank}") : 
    (exists($scriptura{Rank})) ? split(';;', "Tempora: $scriptura{Rank}") : ();
  
  $c1 = $c2 = ''; 
  if (@c1) {
	  my @cf = split('~', setheadline($c1[0], $c1[2]));
    $c1 =  ($c1[3] =~ /(C1[0-9])/) ? setfont($boldblue, $cf[0]) :
        (($c1[2] > 4 || ($c1[0] =~ /Dominica/i)) && $c1[1] !~ /feria/i)
		? setfont($boldred, $cf[0]) : setfont($boldblack, $cf[0]); 
      $c1 = "$c1" . setfont($smallgray, "  $cf[1]");
  } 
  
  if (@c2) {
	  my @cf = split('~', setheadline($c2[0], $c2[2]));
    $c2 = ($c2[3] =~ /(C1[0-9])/) ? setfont($italicblue, $cf[0]) :
      ($c2[2] > 4) ? setfont($italicred, $cf[0]) : setfont($italicblack, $cf[0]); 
    $c2 = "$c2" . setfont ($smallgray, "  $cf[1]");
  } 

  if ($winner =~ /sancti/i) {($c2, $c1) = ($c1, $c2);}
  $c1 =~ s/Hebdomadam/Hebd/i;
  $c1 =~ s/Quadragesima/Quadr/i;
  $c1 =~ s/\s*$//;
  $c2 =~ s/\s*$//;

  if ($dirge) { $c1 .= setfont($smallblack, ' dirge');}

  if (!$c2 && $dayname[2]) {$c2 = setfont($smallblack, $dayname[2]);}
  if ($version !~ /1960/ && $winner{Rule} =~ /\;mtv/i) {$c2 .= setfont($smallblack, ' m.t.v.');}


  $column = 1;
  setcell($c1);
  $column = 2;
  setcell($c2);
  my $cd = sprintf("%02i", $cday);
  my $cdt = "$daynames[$dayofweek] $cd";
  $cell[$searchind - 1][2] = $middleframe->Button(-text=>$cdt, -background=>$framecolor,
    -borderwidth=>$border, -foreground=>$blue,
	-command=>sub{$date1 = "$kmonth-$cd-$kyear", mainpage();}) 
	->grid(-row=>$searchind-1, -column=>2, -sticky=>'nsew', -ipadx=>$padx);
}
  table_end();


$bottomframe = $mwf->Frame(-background=>$framecolor)->pack(-side=>'top', -pady=>$pady);

$bottomframe->Optionmenu(-options=>\@versions,-textvariable=>\$version, #-background=>$framecolor,
   -border=>1, -command=>sub{kalendarrut($kmonth, $kyear);})
   ->pack(-side=>'left', -padx=>$padx);

}

sub setky {
  my $widg = shift;
  my $year = shift;

  my $y = sprintf("%02i", $year % 100);
  $widg->Button(-text=>$y, -background=>$framecolor, -borderwidth=>0, -foreground=>$titlecolor,
    -command=>sub{$kyear = $year; kalendarrut($kmonth, $kyear);})
    ->pack(-side=>'left', -padx=>$padx);
}

sub setkm {
  my $widg = shift;
  my $month = shift;   

  my $m = substr($monthnames[$month-1], 0, 3);
  $widg->Button(-text=>$m, -background=>$framecolor, -borderwidth=>0, -foreground=>$titlecolor,
    -command=>sub{$kmonth = $month; kalendarrut($kmonth, $kyear);})
    ->pack(-side=>'left', -padx=>$padx);
}

sub addattribute {
  my ($font, $attrib, $color) = @_;
  my ($fonttype, $fontsize) = ($font =~ /(\{.*?\})\s+([0-9]+)/) ? ($1, $2) : ('{Times}', 12);
  return "$fonttype $fontsize $attrib $color";
}


sub printcalendar { 
  $kpyear = shift;
  $kpmonth = shift;
  our ($kpmonth, $kpday);
  $printbutton2->configure(text=>'Working', -background=>$red);
  $mw->update();

  if (!open(OUT, ">$datafolder/tmp/Kalendar$year.txt")) {print "$datafolder/tmp/Kalendar$year.txt cannot open!\n"; return;}
  $knames = '';
  if (open(INP, "$datafolder/knames.txt")) {
    while ($l = <INP>) {$knames .= $l;}
	close INP; 
	$knames =~ s/\n/;/g;
	%knames = split(';', $knames);
  }
  
  print OUT " Day  ;Cl;C;----;Principal;Commemoration;2nd Vespers\n";
    print OUT "$monthnames[$kpmonth]\n";
	for ($kpday = 1; $kpday <= $monthlength[$kpmonth]; $kpday++) {
	  $hora = 'Laudes'; 
      $date1 = sprintf("%02i-%02i-%04i", $kpmonth + 1, $kpday, $kpyear);
      $d1 = sprintf("%02i",  $kpday);
      $winner = $commemoratio = $scriptura = '';
      %winner = %commemoratio = %scriptura = {};
      precedence($date1); #for the daily item  
	  
	  $col1 = "$daynames[$dayofweek] $d1";
	  @rank = split(';;', $winner{Rank});
	  $col4 = ''; 
	  $col2 = getkname($winner);
	  if ($col2 =~ /==/) {
	    @col2 = split('==', $col2);
        $col2 = $col2[0];
		$col4 = $col2[1];
	  }
	  $r = $rank[2];    
	  if ($dayofweek == 0 && $rank[0] =~ / (III|II|IV|I|V)\.\s(August|Septembr|Octobr|Novembr|Decembr)/i) 
	    {$col2 .= (' ' . $knames{$1} . ' ' . $knames{$2});} 
      if ($kpmonth == 8 && $rank[0] =~ /Quattuor/i) {$col2 = $knames{"Ember$dayofweek"};}

	  $col3 = ($r >= 6) ? 1 : ($r >= 5) ? 2 : ($r >= 2) ? 3 : 4;
	  if ($commemoratio1) {$col4 .= '=='; $col4 .= getkname($commemoratio1);}
	  if ($commemoratio) {$col4 .= '=='; $col4 .= getkname($commemoratio);}
      $col4 =~ s/^==//;
	  
	  $col5 = ($dayname[0] =~ /Adv|Quad/i) ? 'V' : ($kpmonth == 11 && $kpday > 24) ? 'W' :
	    ($kpmonth == 0 && $kday < 14) ? 'W' : ($dayname[0] =~ /Pasc7/) ? 'R' : ($col2 =~ /^Ember /) ? 'V' : 
		($dayname[0] =~ /Pasc/) ? 'W' : 'G';
      if ($winner =~ /Pent01-0/ || $winner =~ /10-DU/) {$col5 = 'W';}
	  if ($r >= 2 && $winner =~ /Sancti/i && $winner{Rank} =~ /(ex|vide) C[1-3]/ && $winner{Rank} !~ /(ex|vide) C1[0-2]/) 
	    {$col5 = 'R';}
	  elsif ($r >= 2 && $winner =~ /Sancti/i) {$col5 = 'W';}
	  if ($col2 =~ /Vigil/i && $dayname[0] !~ /Pasc/i) {$col5 = 'V';}
	  
      $col6 = '  ';
	  if ($dayofweek == 0 || $r >= 6 || ($winner{Rank} =~ /;;C1/ && $winner{Rank} !~ /;;C10/)) {$col6 = 'Cr';}
	  if ($kpmonth == 11 && $kpday > 24) {$col6 = 'Cr';}
	  if ($r >= 2 && ($winner =~ /Sancti/ || $dayname[0] !~ /Adv|Quad/) && $col5 !~ /V/) {$col6 = 'Gl' . $col6;}
	  elsif ($dayname[0] =~ /Pasc/i) {$col6 = 'Gl' . $col6;}
	  else {$col6 = '  ' . $col6;}

	  $hora = 'Vespera';
	  precedence($date1);
	  $col7 = ''; 
	  if ($vespera == 1) {$col7 = 'Vespers for next day';}

	  print OUT "$col1;$col3 ;$col5;$col6;$col2;$col4;$col7\n";
    }
  
 close OUT;
 $hora = 'Laudes';
 $printbutton->configure(-text=>'PrintCalendar', -background=>$framecolor);
 $mw->update();
}

sub getkname {
  my $item = shift;
  my $key;
  if ($item =~ /Tempora/i && $item =~ /([a-z0-9]+\-[0-9])/i) {
    $key = $1;
	if ($dayofweek == 0 && $kpmonth > 7 && $key =~ /^Epi/) {$key = 'P' . $key;}
	if (exists($knames{$key})) {return $knames{$key};}
	if ($key =~ /Adv/i) {return $knames{Adv};}	
	if ($key =~ /Quad[1-4]/i) {return $knames{Quad};}
	if ($key =~ /Quad5/i) {return $knames{Quad5};}
	if ($key =~ /Pasc/i) {return $knames{Pasc};}
    return 'Feria';
  } 
  if ($item =~ /Sancti/i && $item =~ /([0-9][0-9]\-[0-9D][0-9U])/) {
    $key = $1;
	if (exists($knames{$key})) {return $knames{$key};}
  }
  if ($item =~ /C10/i) {return $knames{C10};}
  %w = officestring("$datafolder/Latin/$item");
  my @r = split(';;', $w{Rank});
  return $r[0];
}
