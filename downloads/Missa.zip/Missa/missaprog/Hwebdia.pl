#!/usr/bin/perl

#�����������
# Name : Laszlo Kiss
# Date : 01-11-04
# WEB dialogs

#use warnings;
#use strict "refs";
#use strict "subs";

my $a = 4;

#*** savesetuphash($name, \%setup)
# saves the referenced setup hash modified by each dialog call
# into $name.setup file
# called by ondestroy callback of MainWindow
sub savesetuphash {
  my $name = shift;
  my $setup = shift;
  my %setup = %$setup; 
  if (open (OUT, ">$datafolder/$name.setup")) {
     my ($key, $value);
	 foreach $key (sort keys %setup) {	
	    print OUT '[' . $key . "]\n";
		$value = $setup{$key};	
		$value =~ s/\n//g;
		$value =~ s/;;/;;\n/g; 
		print OUT "$value\n";  
     }
	 close OUT;
  }
}


#*** htmlHead($title, $flag)
# generated the standard head with $title
sub htmlHead {
  my $title = shift;
  if (!$title) {$title = ' ';}
  $htmltext = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n" .
  "<HTML><HEAD>\n" .
  "<META NAME=\"Resource-type\" CONTENT=\"Document\">\n" .
  "<META NAME=\"description\" CONTENT=\"Divine Office\">\n" .
  "<META NAME=\"keywords\" CONTENT=\"Divine Office, Breviarium, Liturgy, Traditional, Zsolozsma\">\n" .
  "<META NAME=\"Copyright\" CONTENT=\"Like GNU\">\n" .
  "<TITLE>$title</TITLE>\n" .
  "</HEAD>";
}

#*** setfont($font, $text)
# input font description is "[size][ italic][ bold] color" format, and the text
# returns <FONT ...>$text</FONT> string
sub setfont {
  my $istr = shift;
  my $text = shift;
  
  my $size = ($istr =~ /^\.*?([0-9\-\+]+)/i) ? $1 : 0;
  my $color = ($istr =~ /([a-z]+)\s*$/i)  ? $1 : '';
  if ($istr =~ /(\#[0-9a-f]+)\s*$/i || $istr =~ /([a-z]+)\s*$/i) {$color = $1;}

  my $font = "<FONT ";
  if ($size) {$font .= "SIZE=$size ";}
  if ($color) {$font .= "COLOR=\"$color\"";}
  $font .= ">";
  if (!$text) {return $font;}

  my $bold = '';
  my $bolde = '';
  my $italic = '';
  my $italice = '';
  if ($istr =~ /bold/) {$bold = "<B>"; $bolde = "</B>";}
  if ($istr =~ /italic/) {$italic = "<I>"; $italice = "</I>";}
  return "$font$bold$italic$text$italice$bolde</FONT>";
}


#*** setcross($line)
# changes +++, ++ + to crosses in the line
sub setcross {
  my $line = shift; 
  my $csubst = "<IMG SRC=cross3.gif ALIGN=BASELINE ALT=cross3>";
  $line =~ s/\+\+\+/$csubst/g;
  $csubst = "<IMG SRC=cross2.gif ALIGN=BASELINE ALT=cross2>";
  $line =~ s/\+\+/$csubst/g;
  $csubst = "<IMG SRC=cross1.gif ALIGN=BASELINE ALT=cross1>";
  $line =~ s/ \+ / $csubst /g;
  return $line;
}

#*** setcell($text1, $lang1);
# output the content of the cell
sub setcell {
  my $text = shift;
  my $lang = shift; 
  
  my $width = ($only) ? 100 : 50;
  if (columnsel($lang)) {
    $searchind++; $line .=  "<TR>";
  }
  
  $text =~ s/wait[0-9]+//ig;
  $text =~ s/\{\:.*?\:\}//g;
  $text =~ s/\_/ /g;
  $text =~ s/[%`]//g;
  if ($text =~ /\{ (.*?) \}/) {$text = "$`<BR>" . setfont($smallblack, $1) . $';}

  
  $htmltext .=  "<TD $background VALIGN=TOP WIDTH=$width% ID=L$searchind>"; 
  $htmltext .=  setfont($blackfont,$text) . "</TD>\n";
  if ($only || !columnsel($lang)) {$htmltext .= "<\TR>\n";} 
} 

#*** topnext_Cell() 
#prints T N for positioning
sub topnext_cell {
    my $lang = shift;
    my @a = split('<BR>', $text1);
    if (@a > 2 && $expand !~ /skeleton/i) {return topnext($lang); }
}

sub topnext {
  my $lang = shift;
  my $str = "<FONT SIZE=1 COLOR=green><DIV ALIGN=right>";
  if (columnsel($lang)) {
    $str .= "<A HREF=# onclick=\"setsearch($searchind);\">Top</A>&nbsp;&nbsp;";
    $str .= "<A HREF=# onclick=\"setsearch($searchind+1);\">Next</A>";
  } else {$str .= "$searchind";}
  $str .=  "</DIV></FONT>\n";
  return $str;
}
    
#*** table_start
# start main table
sub table_start {
  $htmltext .= "<TABLE BORDER=0 ALIGN=CENTER CELLPADDING=8 CELLSPACING=$border BGCOLOR='maroon' WIDTH=80%>";
}

#antepost('$title')
# prints Ante of Post call
sub ante_post {
  return;
  my $title = shift;
  my $colspan = ($only) ? '' : 'COLSPAN=2';

  $htmltext .= "<TR><TD $background VALIGN=TOP $colspan ALIGN=CENTER>\n" .
   "<INPUT TYPE=RADIO NAME=link onclick='linkit(\"\$$title\", 0, \"Latin\");'>\n" .
   "<FONT SIZE=1>$title Divinum officium</FONT></TD></TR>";
}

#table_end()
# finishes main table
sub table_end {
  $htmltext .= "</TABLE><span ID=L$searchind></span>";
}

#*** htmlcall($ref, $lang);
# returns the html come
sub htmlcall {
  my $ref = shift;
  my $lang = shift;
  return "<A HREF=\"$ref$lang.htm\" TARGET=_NEW>$ref</A>\n";
}

